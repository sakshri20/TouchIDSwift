//
//  ViewController.swift
//  Touch_ID_Demo
//
//  Created by Sakshi Shrivastava on 12/5/17.
//  Copyright © 2017 Sakshi Shrivastava. All rights reserved.
//

import UIKit

// Keychain Configuration
struct KeychainConfiguration {
    static let serviceName = "TouchMeIn"
    static let accessGroup: String? = nil
}

class ViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var touchIdButton: UIButton!
    
    
    var passwordItems: [KeychainPasswordItem] = []
    let createLoginButtonTag = 0
    let loginButtonTag = 1
    let touchMe = TouchIDAuth()
    
    @IBOutlet weak var loginButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 1
        let hasLogin = UserDefaults.standard.bool(forKey: "hasLoginKey")
        
        // 2
        if hasLogin {
            loginButton.setTitle("Login", for: .normal)
            loginButton.tag = loginButtonTag
            //createInfoLabel.isHidden = true
        } else {
            loginButton.setTitle("Create", for: .normal)
            loginButton.tag = createLoginButtonTag
          //  createInfoLabel.isHidden = false
        }
        
        // 3
        if let storedUsername = UserDefaults.standard.value(forKey: "username") as? String {
            emailTextField.text = storedUsername
        }
        // Do any additional setup after loading the view, typically from a nib.
        self.touchIdButton.isHidden = !touchMe.canEvaluatePolicy()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loginButtonPressed(_ sender: UIButton) {
        
        // 1
        // Check that text has been entered into both the username and password fields.
        guard
            let newAccountName = emailTextField.text,
            let newPassword = passwordTextField.text,
            !newAccountName.isEmpty &&
                !newPassword.isEmpty else {
                    
                    let alertView = UIAlertController(title: "Login Problem",
                                                      message: "Wrong username or password.",
                                                      preferredStyle:. alert)
                    let okAction = UIAlertAction(title: "Foiled Again!", style: .default, handler: nil)
                    alertView.addAction(okAction)
                    present(alertView, animated: true, completion: nil)
                    return
        }
        
        // 2
        emailTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        
        // 3
        if sender.tag == createLoginButtonTag {
            
            // 4
            let hasLoginKey = UserDefaults.standard.bool(forKey: "hasLoginKey")
            if !hasLoginKey {
                UserDefaults.standard.setValue(emailTextField.text, forKey: "username")
            }
            
            // 5
            do {
                
                // This is a new account, create a new keychain item with the account name.
                let passwordItem = KeychainPasswordItem(service: KeychainConfiguration.serviceName,
                                                        account: newAccountName,
                                                        accessGroup: KeychainConfiguration.accessGroup)
                
                // Save the password for the new item.
                try passwordItem.savePassword(newPassword)
            } catch {
                fatalError("Error updating keychain - \(error)")
            }
            
            // 6
            UserDefaults.standard.set(true, forKey: "hasLoginKey")
            loginButton.tag = loginButtonTag
            self.performSegue(withIdentifier: "WelcomeSegue", sender: self)
        } else if sender.tag == loginButtonTag {
            
            // 7
            if checkLogin(username: emailTextField.text!, password: passwordTextField.text!) {
                self.performSegue(withIdentifier: "WelcomeSegue", sender: self)
            } else {
                // 8
                let alertView = UIAlertController(title: "Login Problem",
                                                  message: "Wrong username or password.",
                                                  preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Foiled Again!", style: .default)
                alertView.addAction(okAction)
                present(alertView, animated: true, completion: nil)
            }
        }
        
//        if self.emailTextField.text == "sakshi" && self.passwordTextField.text == "1234"{
//            DispatchQueue.main.async {
//                let storyboard = UIStoryboard(name:"Main", bundle:nil)
//                let vc = storyboard.instantiateViewController(withIdentifier: "WelcomeScreen")
//                self.navigationController?.pushViewController(vc, animated: true)
//            }
//        }
    }
    
    func checkLogin(username: String, password: String) -> Bool {
        
        guard username == UserDefaults.standard.value(forKey: "username") as? String else {
            return false
        }
        
        do {
            let passwordItem = KeychainPasswordItem(service: KeychainConfiguration.serviceName,
                                                    account: username,
                                                    accessGroup: KeychainConfiguration.accessGroup)
            let keychainPassword = try passwordItem.readPassword()
            return password == keychainPassword
        }
        catch {
            fatalError("Error reading password from keychain - \(error)")
        }
        
        return false
    }
    
    
    @IBAction func touchIdButtonPressed(_ sender: UIButton) {
        
        // 1
        touchMe.authenticateUser() { message in
            
            // 2
            if let message = message {
                // if the completion is not nil show an alert
                let alertView = UIAlertController(title: "Error",
                                                  message: message,
                                                  preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Darn!", style: .default)
                alertView.addAction(okAction)
                self.present(alertView, animated: true)
                
            } else {
                // 3
                self.performSegue(withIdentifier: "WelcomeSegue", sender: self)
            }
        }
        
    }
    
    
}

